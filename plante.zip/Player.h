#ifndef PLAYER_H
#define PLAYER_H

#include <string>
#include "Plante.h"

class Player{
  private:
    std::string _playerName;
  
  public:
  
    void amuser(Plante * cible);
    void nourrir(Plante * cible);
    void border(Plante * cible);
    
    
    Player(std::string nomPlayer);
    
};

#endif