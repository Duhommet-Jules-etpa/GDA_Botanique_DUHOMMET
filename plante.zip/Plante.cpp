#ifndef Plante_CPP
#define Plante_CPP

#include <iostream>
#include "Plante.h" 

/*    int _ennui; int _fatigue; int _faim; std::string _nom; */
  

    void Plante::tailler(){    }
    
    void Plante::arroser(int eau){    }
    
    void Plante::pousser(int engrais){    }
    
    void Plante::afficher(){
        std::cout << _nom << " est un Plante, a une faim de " 
                << _soif << "/100, une fatigue de "
                << _sante << "/100, et un ennui de "<< std::endl;
    }
    
    Plante::Plante(std::string name) : _nom(name), _sante(75), _soif(20)  {}

#endif