#ifndef Tournesol_H
#define Tournesol_H

#include <string>
#include "Plante.h"

class Tournesol : public Plante {

  
  public:
  
    void tailler();
    void arroser(int eau);
    void pousser(int engrais);
    
    void afficher();
    
    Tournesol(std::string name);
    
};

#endif