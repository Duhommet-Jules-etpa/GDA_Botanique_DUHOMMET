#ifndef Plante_H
#define Plante_H

#include <string>

class Plante
{
protected:
  int _sante;
  int _soif;
    std::string _nom;

public:

  void virtual tailler ();
  void virtual arroser (int eau);
  void virtual pousser (int engrais);

  void afficher ();

    Plante (std::string name);

};

#endif
