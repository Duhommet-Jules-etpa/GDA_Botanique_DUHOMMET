/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include "Tournesol.h"
#include "Player.h"

int main()
{
    
    Tournesol * link = new Tournesol("Plante");
    link->afficher();
    
    Player * myself = new Player("Botaniste");
    
    printf("Vous venez d'arroser la plante elle a donc moins soif.\n");
    myself->nourrir(link);
    link->afficher();

    return 0;
}
