#ifndef PLAYER_CPP
#define PLAYER_CPP

#include <string>
#include "Player.h"
#include "Plante.h"

// std::string _playerName;
  
  
    void Player::amuser(Plante * cible){
        cible->tailler();
    }
    
    void Player::border(Plante * cible){
        cible->arroser(20);
    }
    
    void Player::nourrir(Plante * cible){
        cible->pousser(1);    
    }
    
    
    Player::Player(std::string nomPlayer): _playerName(nomPlayer) {}
    
#endif