#ifndef Tournesol_CPP
#define Tournesol_CPP

#include <iostream>
#include "Tournesol.h"
#include "Plante.h"

  

    void Tournesol::tailler(){
        
        _sante+=30;
    }
    
    void Tournesol::arroser(int eau){
        _soif-=eau;
        if(_soif<0) _soif=0;
        _sante+=30;
    }
    
    void Tournesol::pousser(int heures){
        _sante-=heures*10;
        if(_sante<0) _sante=0;
        _soif+=30;
    }
    
    void Tournesol::afficher(){
        std::cout << _nom << " est un Tournesol,il a une soif de " 
                << _soif << "/100 et il a une santé de  "
                << _sante << "/100 il est en grande forme"<< std::endl;
    }
    
    Tournesol::Tournesol(std::string name) : Plante(name) {}

#endif